<?php
 // variable system
 echo 'Dokumen Root '.$_SERVER["Document_ROOT"];
 echo '<br/>Nama File '.$_SERVER["PHP_SELF"];
 ?>