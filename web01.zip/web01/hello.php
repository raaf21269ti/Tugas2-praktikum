<?php
  echo '<h1>Selamat Belajar PHP</h1>';
?>